﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhoneBookSky
{
    public partial class formPhoneBook : Form
    {
        public formPhoneBook()
        {
            InitializeComponent();
        }
        //We will be using 4 classes for the load event:
        //1. SqlConnection
        //This class is used to setup the database connection for the event (Form Load Event in this case)
        //2. SqlCommand
        //This class is used to utilize Sql Commands (SELECT, INSERT, UPDATE and DELETE)
        //3. SqlDataAdapter
        //It's used to execute SQL queries
        //4. DataSet
        //Used to handle the data after the query is executed

        SqlConnection con = new SqlConnection();
        private void formPhoneBook_Load(object sender, EventArgs e)
        {
            //Setup the database connection string for the load event
            con.ConnectionString = ConfigurationManager.ConnectionStrings["dbConnection"].ToString();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;

            cmd.CommandText = "SELECT * FROM tb_PhoneBook";
            
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);

            dgvPhoneBook.DataSource = ds.Tables[0];
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            con.ConnectionString = ConfigurationManager.ConnectionStrings["dbConnection"].ToString();
            SqlCommand cmd = new SqlCommand("INSERT INTO tb_PhoneBook VALUES ('"+txtName.Text+"', '"+txtRelationship.Text+"', '"+txtContactNo.Text+"', '"+txtAddress.Text+"', '"+txtDescription.Text+"' )", con);
            cmd.Connection = con;

            //Executes the query to send the data to the database
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
    }
}
